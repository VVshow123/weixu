﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;

namespace queryNewsIndex
{
    class getlastTiers
    {
        public static string targetFolder = @"https://cosmos09.osdinfra.net/cosmos/SPIN.Compute/shares/ipe.platform.dsi/LMData/LMSources/NewsIndex/";
        public static string targetFolderShort = @"/shares/ipe.platform.dsi/LMData/LMSources/NewsIndex/";

        public static Regex targetFolderRegex = new Regex(@"^.*\/([a-z]{2}-[A-Z]{2})\/\d{4}\/\d{2}\/newsarticles\.[a-z]{2}-[a-z]{2}\.(\d{4}-\d{2}-\d{2})\.ss$", RegexOptions.Compiled);

        /// <summary>
        /// Base snap shot query
        /// </summary>
        /// <param name="inputStream"></param>
        /// <param name="locale"></param>
        /// <param name="outputBaseStream"></param>
        /// <returns></returns>
        public static string NewIndexBaseQuery(string inputStream, string outputBaseStream)
        {
            string tempScript = Path.GetTempPath() + "newsIndexupdatelog.basequery." + Path.GetRandomFileName() + @".script";
            System.Console.WriteLine("Generate Base query: {0}", tempScript);
            StringBuilder queryNewsSnapShots = new StringBuilder();
            StreamWriter scriptSW = new StreamWriter(File.Create(tempScript), Encoding.ASCII);

            //generate process script
            scriptSW.WriteLine(@"REFERENCE @""/shares/searchWebLoad/RetroIndex/bin/RetroIndexProcessor.dll"";");
            scriptSW.WriteLine("sstream = SELECT Url,Body,Header,HttpHeader,CodePage FROM ( SSTREAM \"{0}\");", inputStream);
            scriptSW.WriteLine(@"retroindex_processed = PROCESS sstream");
            scriptSW.WriteLine("PRODUCE Url,\nRealTimeType,\nDescription,\nCountry,\nNewsSource,\nNewsSourcePingFrequency,\nNewsSourceAuthority,\nDiscoveryStringTime,\nLanguage,\nTitle, \nNewsArticleDescription ,\nDUODP \nUSING RetroIndexProcessor \nHAVING CommonHelper.IsNewsArticle(RealTimeType) == true ;");
            scriptSW.WriteLine("OUTPUT retroindex_processed TO SSTREAM @\"{0}\" RANGE CLUSTERED BY Url INTO 600;", outputBaseStream);
            scriptSW.WriteLine("#CS \npublic static class CommonHelper  \n{public static bool IsNewsArticle(string RealtimeType){  \n try   \n {int t = int.Parse(RealtimeType); \n return t % 2 != 0;   \n }   \n catch \n   {return false;  }\n}\n}\n#ENDCS");
            scriptSW.Close();
            //setup resource for script, include dll and so forth
            List<string> queryBaseResource = new List<string>();
            queryBaseResource.Add(@"/shares/searchWebLoad/RetroIndex/bin/RetroIndexProcessor.dll");
            return cosmosHelper.submitJob(tempScript, @"query_newsIndex_base_snapshort", queryBaseResource);
        }

        public static string getLastfiles(Dictionary<string, List<VcClient.StreamInfo>> files)
        {
            string[] dateList = files.Keys.ToArray();
            DateTime latestDate = Convert.ToDateTime(dateList[0]);
            for (int i = 1; i < dateList.Length; i++)
            {
                DateTime tempdate = Convert.ToDateTime(dateList[i]);
                latestDate = DateTime.Compare(latestDate, tempdate) > 0 ? latestDate : tempdate;
            }
            return latestDate.ToString("yyyy-MM-dd");
        }

        /// <summary>
        /// Query for each locale and split data by day
        /// </summary>
        /// <param name="snapshots"></param>
        /// <param name="locale"></param>
        /// <param name="startDate"></param>
        /// <param name="latestDate"></param>
        /// <returns></returns>
        public static string SplitByDays(List<string> snapshots, string locale, string startDate, string latestDate)
        {
            string joid = null;
            string tempScript = Path.GetTempPath() + "newsIndexupdatelog.basequery_" + locale + "_" + Path.GetRandomFileName() + ".script";
            StringBuilder queryNewsSnapShots = new StringBuilder();
            StreamWriter scriptSW = new StreamWriter(File.Create(tempScript), Encoding.ASCII);
            System.Console.WriteLine("Start Prepare {0}", tempScript);
            //generate process script
            scriptSW.WriteLine(@"#DECLARE output string = @""""; ");
            int i = 0;
            foreach (var snapshot in snapshots)
            {
                string languageID;
                string countryID;
                ConvertCountryID(locale, out languageID, out countryID);
                scriptSW.WriteLine("sstreamSnapshot{0} =  SELECT Url,", i);
                scriptSW.WriteLine("\tTitle,\n\tDiscoveryStringTime AS DiscoveryTime,\n\tNewsArticleDescription AS Text,\n\tDUODP AS DocumentDomain,\n\tNewsSource,\n\tNewsSourcePingFrequency,\n\tNewsSourceAuthority");
                scriptSW.WriteLine("FROM(SSTREAM \"{0}\") WHERE Language.ToLower() == \"{1}\" AND Country.ToLower() == \"{2}\";", snapshot, languageID.ToLower(), countryID.ToLower());
                i++;
            }
            i = 0;
            scriptSW.WriteLine("allStreams =  SELECT * FROM sstreamSnapshot{0}", i);
            for (i = 1; i < snapshots.Count; i++)
            {
                scriptSW.WriteLine("UNION ALL");
                scriptSW.WriteLine("SELECT * FROM sstreamSnapshot{0}", i);
            }
            scriptSW.WriteLine(";");
            DateTime indexXDate = Convert.ToDateTime(startDate);
            System.Console.WriteLine("Date:");
            while (DateTime.Compare(indexXDate, Convert.ToDateTime(latestDate).AddDays(-1)) < 0)
            {
                string indexTargetData = targetFolderShort + locale + @"/" + indexXDate.Year.ToString().PadLeft(4, '0') + @"/" + indexXDate.Month.ToString().PadLeft(2, '0') + @"/" + @"newsarticles." + locale.ToLower() + @"." + indexXDate.ToString("yyyy-MM-dd") + @".ss";
                scriptSW.WriteLine("#SET output = @\"{0}\";", indexTargetData);
                scriptSW.WriteLine("final = SELECT Url,\n\tTitle,\n\tDiscoveryTime,\n\tText, \n\tDocumentDomain,\n\tNewsSource,\n\tNewsSourcePingFrequency, \n\tNewsSourceAuthority \nFROM allStreams ");
                scriptSW.WriteLine("WHERE DiscoveryTime.Contains(\"{0}\") == true;", indexXDate.ToString("yyyy-MM-dd"));
                scriptSW.WriteLine("OUTPUT final TO SSTREAM @output;");
                indexXDate = indexXDate.AddDays(1);
            }
            scriptSW.Close();
            //setup resource for script, include dll and so forth
            List<string> queryBaseResource = new List<string>();
            System.Console.WriteLine("Submitting job");
            joid = cosmosHelper.submitJob(tempScript, @"query_newsIndex_" + locale, queryBaseResource);
            File.Delete(tempScript);
            return joid;
        }

        public static Dictionary<string, string> checkUpdate(string file, string date, out bool updateFlag)
        {
            Dictionary<string, string> locales = new Dictionary<string, string>();
            List<string> files = new List<string>();
            string templog = Path.GetTempPath() + "CheckNewsIndexUpdatelog." + Path.GetRandomFileName() + ".log";
            if (cosmosHelper.checkFile(file))
            {
                cosmosHelper.downloadCosmosFile(file, templog);
                System.Threading.Thread.Sleep(2000); 
                using (StreamReader logSR = new StreamReader(templog, Encoding.UTF8))
                {
                    string line = logSR.ReadLine();
                    DateTime updateTill = Convert.ToDateTime(line);
                    DateTime dataTill = Convert.ToDateTime(date);
                    updateFlag = DateTime.Compare(dataTill, updateTill) > 0 ? true : false;
                    //File.Delete(templog);
                    while ((line = logSR.ReadLine()) != null)
                    {
                        string[] locaeinfo = line.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                        if (locaeinfo.Length == 2)
                        {
                            if (!locales.Keys.Contains(locaeinfo[0]))
                                locales.Add(locaeinfo[0], locaeinfo[1]);
                        }
                        else
                        {
                            System.Console.WriteLine("Log file format is not correct{0}", line);
                            Environment.Exit(-1);
                        }
                    }

                }
                File.Delete(templog);
            }
            else
            {
                cosmosHelper.SearchFiles(targetFolder, targetFolderRegex, files);
                locales = FindLatestDate(files);
                updateFlag = true;
            }
            return locales;
        }

        public static Dictionary<string, string> FindLatestDate(List<string> files)
        {
            Dictionary<string, string> locales = new Dictionary<string, string>();
            foreach (var file in files)
            {
                Match fileMatch = targetFolderRegex.Match(file);
                if (fileMatch.Success)
                {
                    if (locales.Keys.Contains(fileMatch.Groups[1].Value.ToString()))
                    {
                        DateTime tempatedate = Convert.ToDateTime(locales[fileMatch.Groups[1].Value.ToString()]);
                        DateTime currentdate = Convert.ToDateTime(fileMatch.Groups[2].Value.ToString());
                        locales[fileMatch.Groups[1].Value.ToString()] = DateTime.Compare(currentdate, tempatedate) > 0 ? currentdate.ToString("yyyy-MM-dd") : tempatedate.ToString("yyyy-MM-dd");
                    }
                    else
                    {
                        DateTime currentdate = Convert.ToDateTime(fileMatch.Groups[2].Value.ToString());
                        locales[fileMatch.Groups[1].Value.ToString()] = currentdate.ToString("yyyy-MM-dd");
                    }
                }
            }
            return locales;
        }

        public static void ConvertCountryID(string locale, out string languageID, out string countryID)
        {
            Regex localeRegex = new Regex(@"^([a-z]{2})-([A-Z]{2})$");
            languageID = null;
            countryID = null;
            Match localeMatch = localeRegex.Match(locale);
            if (localeMatch.Success)
            {
                switch (locale)
                {
                    case "zh-CN":
                        languageID = @"zh_chs";
                        break;
                    case "zh-TW":
                        languageID = @"zh_cht";
                        break;
                    case "zh-HK":
                        languageID = @"zh_cht";
                        break;
                    default:
                        languageID = localeMatch.Groups[1].Value.ToString();
                        break;
                }
                countryID = localeMatch.Groups[2].Value.ToString();
            }
            else
            {
                System.Console.WriteLine("Parse Locale information failed{0}", locale);
                Environment.Exit(-1);
            }
        }

        public static void WriteLog(string snapshotDate, Dictionary<string, string> locales, string logfile)
        {
            string templog = Path.GetTempPath() + Path.GetRandomFileName() + "CheckUpdateFile.log";
            using (StreamWriter log = new StreamWriter(File.Create(templog), Encoding.ASCII))
            {
                log.WriteLine("{0}", snapshotDate);
                foreach (var locale in locales)
                {
                    DateTime indexXDate = Convert.ToDateTime(snapshotDate).AddDays(-1);
                    log.WriteLine("{0},{1}", locale.Key, indexXDate.ToString("yyyy-MM-dd"));
                }
            }
            cosmosHelper.updateFile2Cosmos(templog, logfile, true);
        }
    }
}
