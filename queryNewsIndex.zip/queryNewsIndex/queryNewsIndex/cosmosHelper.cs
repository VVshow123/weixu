﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

namespace queryNewsIndex
{
    class cosmosHelper
    {
        private static Regex cosmosPathRegex = new Regex(@"^https://(cosmos\d+)\.osdinfra\.net:?\d*/cosmos/([^/]+)(/.*)/([^/]+)\.([a-z]+)$", RegexOptions.IgnoreCase);
        private static string Vcname = @"https://cosmos09.osdinfra.net/cosmos/SPIN.Compute/"; 
        public static void QuryJob(string jobname)
        {
            VcClient.FindJobsParameters paramters = new VcClient.FindJobsParameters();
            paramters.UserName = Environment.UserDomainName + @"\" + Environment.UserName;
            paramters.VcName = Vcname;
            paramters.JobNameRegex = jobname;
            try
            {
                VcClient.JobList jobs = VcClient.VC.FindJobs(paramters);
                string jobCosmosID = "";
                string jobCosmosStatus = "Unkown";
                if (CheckJobs(jobs, out jobCosmosID, out jobCosmosStatus))
                {
                    System.Console.Write("\r[{0}]Check Job {1}:\t {2}", DateTime.Now.ToString("yyy-MM-dd HH:mm"), jobCosmosID, jobCosmosStatus);
                    CheckInterval();
                    QuryJob(jobname);
                }
            }
            catch(Exception e)
            {
                //if sever refused responds, sleep 10 mins
                System.Console.Write("\r[{0}Query Job no responds: server refused! Sleep 10 Mins", DateTime.Now.ToString("yyy-MM-dd HH:mm")); 
                System.Threading.Thread.Sleep(600000);
                QuryJob(jobname); 
            }
        }

        public static bool CheckJobs(VcClient.JobList jobs, out string jobCosmosID, out string jobStatus)
        {
            bool checkInterveral = false;
            jobCosmosID = "";
            jobStatus = "Unknown"; 
            foreach (var job in jobs.Jobs)
            {
                if (job.State != VcClient.JobInfo.JobState.CompletedSuccess)
                {
                    jobCosmosID = job.ID.ToString();
                    jobStatus = job.State.ToString(); 
                    checkInterveral = true;
                }
            }
            return checkInterveral;
        }

        public static void CheckInterval()
        {
            System.Threading.Thread.Sleep(180000);
        }

        public static string submitJob(string script, string jobname, List<string> jobResources)
        {
            string jodId = Guid.NewGuid().ToString();
            VcClient.SubmitJobParameters parameters = new VcClient.SubmitJobParameters();
            parameters.Name = jobname + "_" + jodId;
            parameters.ScopeScriptFileNameOrCmdOrGraph = script;
            parameters.Priority = 500;
            parameters.Resources = jobResources;
            parameters.VcName = @"https://cosmos09.osdinfra.net/cosmos/SPIN.Compute/";
            try
            {
                VcClient.VC.SubmitJob(parameters, true);
              
            }
            catch(Exception e)
            {
                Console.WriteLine("Submit Job failed {0} \t{1}",e.ToString(),  script);
                Environment.Exit(-1); 
            }
            File.Delete(script);
            return jodId;
        }

        public static bool parseCosmosPath(string inputfile, out string vc, out string vcfull, out string relavtivepath, out string filename, out string extension)
        {
            Match cosmosPathMatch = cosmosPathRegex.Match(inputfile);
            bool sucess = cosmosPathMatch.Success;
            if (sucess)
            {
                vc = @"vc://" + cosmosPathMatch.Groups[1].ToString() + @"/" + cosmosPathMatch.Groups[2].ToString();
                relavtivepath = cosmosPathMatch.Groups[3].ToString();
                filename = cosmosPathMatch.Groups[4].ToString() + @"." + cosmosPathMatch.Groups[5].ToString();
                extension = cosmosPathMatch.Groups[5].ToString();
                vcfull = Regex.Replace(inputfile, (relavtivepath + @"/" + filename), "");
            }
            else
            {
                vc = null;
                relavtivepath = null;
                extension = null;
                filename = null;
                vcfull = null;
            }
            return sucess;
        }

        public static void findFiles(string path, Regex wc, Dictionary<string, List<VcClient.StreamInfo>> files)
        {
            try
            {
                List<VcClient.StreamInfo> cosmosFiles = VcClient.VC.GetDirectoryInfo(path, true);
                foreach (VcClient.StreamInfo item in cosmosFiles)
                {
                    if (!item.IsDirectory)
                    {
                        Match wcm = wc.Match(item.StreamName);
                        if (wcm.Success)
                        {
                            string date = wcm.Groups[1].ToString() + "-" + wcm.Groups[2].ToString() + "-" + wcm.Groups[3].ToString();
                            if (files.Keys.Contains(date))
                            {
                                files[date].Add(item);
                            }
                            else
                            {
                                List<VcClient.StreamInfo> tempStreaminfo = new List<VcClient.StreamInfo>();
                                tempStreaminfo.Add(item);
                                files.Add(date, tempStreaminfo);
                            }
                            //files.Add(item);
                        }
                    }
                    else
                    {
                        findFiles(item.StreamName, wc, files);
                    }
                }
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.ToString());
            }
        }

        public static void SearchFiles(string path, Regex wc, List<string> files)
        {
            try
            {
                List<VcClient.StreamInfo> cosmosFiles = VcClient.VC.GetDirectoryInfo(path, true);
                foreach (VcClient.StreamInfo item in cosmosFiles)
                {
                    if (!item.IsDirectory)
                    {
                        Match wcm = wc.Match(item.StreamName);
                        if (wcm.Success)
                        {
                            files.Add(item.StreamName);
                        }
                    }
                    else
                    {
                        SearchFiles(item.StreamName, wc, files);
                    }
                }
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.ToString());
            }
        }

        public static bool updateFile2Cosmos(string sourcefile, string targetfile, bool overwrite)
        {
            if (checkFile(targetfile))
            {
                if (overwrite)
                {
                    VcClient.VC.Delete(targetfile);
                }
                else
                {
                    System.Console.WriteLine("Target file exist: {0} \n set overwrite able", targetfile);
                    return false;
                }

            }
            VcClient.VC.Upload(sourcefile, targetfile, false);
            return checkFile(targetfile);
        }

        public static bool downloadCosmosFile(string file, string targetFile)
        {
            bool success = false;

            try
            {
                if (File.Exists(targetFile))
                {
                    File.Delete(targetFile);
                }
                VcClient.VC.Download(file, targetFile, false, true);
                success = true;
            }
            catch (Exception e)
            {
                success = false;
            }
            return success;
        }

        public static bool checkFile(string file)
        {
            return VcClient.VC.StreamExists(file);
        }

        public static bool IsCosmosPath(string path)
        {
            return cosmosPathRegex.IsMatch(path);
        }

        public static bool DeleteCosmosFile(string cosmosPath)
        {
            bool deleteFlag = false;
            try
            {
                VcClient.VC.Delete(cosmosPath);
                System.Console.WriteLine("Delete Success \t{0}", cosmosPath);
            }
            catch (Exception e)
            {
                deleteFlag = false;
                Environment.Exit(-1);
                System.Console.WriteLine("Delete Failed\n{0}", e);
            }
            return deleteFlag;
        }

    }
}
