﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace queryNewsIndex
{
    class Program
    {

        static void Main(string[] args)
        {
            while (true)
            {
                QueryData();
                System.Console.WriteLine("Done check query: sleep {8} Hours"); 
                System.Threading.Thread.Sleep(28800000);
            }
        }

        public static void QueryData()
        {
            string searchWebDir = @"https://cosmos09.osdinfra.net/cosmos/SPIN.Compute/shares/searchWebLoad/RetroIndex/Snapshot/";
            string logdate = @"https://cosmos09.osdinfra.net/cosmos/SPIN.Compute/shares/ipe.platform.dsi/LMData/LMSources/NewsIndex/newIndex.log";
            List<string> intermediaSnapshots = new List<string>();
            Regex filterRegex = new Regex(@"^.*(\/shares\/.*)$");
            Regex snapshotRegex = new Regex(@"^.*\/(\d{4})\/(\d{2})\/(\d{2})\/Tier_0\/snapshot_(\d+)\.ss$", RegexOptions.IgnoreCase);

            var dirinfo = VcClient.VC.GetDirectoryInfo(searchWebDir, false);
            Dictionary<string, List<VcClient.StreamInfo>> files = new Dictionary<string, List<VcClient.StreamInfo>>();

            //step 1: find the latest snapshot
            System.Console.WriteLine("Start: Search SnapShot");
            cosmosHelper.findFiles(searchWebDir, snapshotRegex, files);
            string latestDate = getlastTiers.getLastfiles(files);


            //step 2: query news index on snapshot
            bool updateFlag = false;
            System.Console.WriteLine("{0}\tSearch Current NewsIndex", DateTime.Now.ToString("yyy-MM-dd HH:mm"));
            Dictionary<string, string> locales = getlastTiers.checkUpdate(logdate, latestDate, out updateFlag);
            Dictionary<string, string> baseQueryJobs = new Dictionary<string, string>();
            if (updateFlag)
            {
                List<VcClient.StreamInfo> newindexSnaps = files[latestDate];
                foreach (var snaps in newindexSnaps)
                {
                    string filepath = snaps.StreamName;
                    filepath = filterRegex.Replace(filepath, @"$1");
                    Match fileMatch = snapshotRegex.Match(filepath);

                    string outputBaseStream = @"/shares/ipe.platform.dsi/LMData/LMSources/NewsIndex/newIndexBase.snapshot" + fileMatch.Groups[4] + @".ss";
                    string jobID = getlastTiers.NewIndexBaseQuery(filepath, outputBaseStream);
                    System.Console.WriteLine("Query snapshot: \r{0}", fileMatch.Groups[4]);
                    cosmosHelper.QuryJob(jobID);
                    baseQueryJobs.Add(jobID, outputBaseStream);
                    intermediaSnapshots.Add(@"https://cosmos09.osdinfra.net/cosmos/SPIN.Compute" + outputBaseStream);
                }
                System.Console.WriteLine("{0}\tFinish: Base query for snapshot", DateTime.Now.ToString("yyy-MM-dd HH:mm"));
                //step 3: query news data for each locales
                foreach (var locale in locales.Keys)
                {
                    string jobName = getlastTiers.SplitByDays(baseQueryJobs.Values.ToList(), locale, locales[locale], latestDate);
                    cosmosHelper.QuryJob(jobName);
                }

                foreach (var intermediaData in intermediaSnapshots)
                {
                    cosmosHelper.DeleteCosmosFile(intermediaData);
                }

                //Done: write logs
                getlastTiers.WriteLog(latestDate, locales, logdate);
                System.Console.WriteLine("{0}\tUpdate News Index Done", DateTime.Now.ToString("yyy-MM-dd HH:mm"));

            }
            else
            {
                System.Console.WriteLine("no update");
            }
        }
    }
}
